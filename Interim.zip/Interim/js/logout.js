setTimeout(autoLogout, 5000); //miliseconds

function autoLogout()
{
    window.location = "index.php";
}